# Daily Meds

Sistema de información para la gestión y organización de medicamentos.

## Descripción

Daily Meds es un sistema de información orientado a la gestión y organización de medicamentos. Este repositorio contiene el diseño técnico inicial y la base del proyecto.

## Integrantes

- Axel Osmir Millón Hernández – Rol: por definir
- Bayron Miguel Rivas Cordonero – Rol: por definir

## Curso

Integrador II – Ingeniería de Sistemas, UNAN-Managua (2026)

## Estructura del proyecto

- `docs/` – documentación y diseño técnico del sistema.
- `src/` – código fuente.
- `database/` – modelo de datos y scripts de base de datos.

## Estado

Semana 6 – Diseño técnico inicial.
