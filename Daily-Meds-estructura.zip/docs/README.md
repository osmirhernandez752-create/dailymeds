# Documentación

Aquí se guardará la documentación del proyecto: diseño técnico inicial, modelado de procesos y demás documentos del sistema Daily Meds.
