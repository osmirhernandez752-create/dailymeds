# Base de datos

Aquí se guardarán el modelo de datos (entidades y atributos) y los scripts de la base de datos del sistema Daily Meds.
